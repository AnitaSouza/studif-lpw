<?php
    class Login{
        private $email_login;
        private $senha_login;

        public function exibirDados(){
            echo "<br />";
            echo "O email é ". $this->email_login;
            echo "<br />";
            echo "A senha é ". $this->senha_login;
        }

        public function __construct($email_login, $senha_login){
            $this->email_login = $email_login;
            $this->senha_login = $senha_login;
            echo "<br />login concluído...";
        }

        public function setEmail_login($email_login){
            $this->email_login = $email_login;
        }
        
        public function getEmail_login(){
            return $this->email_login;
        }

        public function setSenha_login($senha_login){
            $this->senha_login = $senha_login;
        }
        
        public function getSenha_login(){
            return $this->senha_login;
        }

        public function inserirLogin()
        {
            //Conectar com o BD
            $conexao = mysqli_connect("localhost","root","", "studif");
            
            //Verificando a conexão
            if(!$conexao){
                die("Falha na conexão com o BD");
            }
            echo "Conectado com o banco";

            //Criando a string de inserção (código SQL)
            $sql = "INSERT INTO login VALUES ('$this->email_login', '$this->senha_login')";
           
            //Executando a inserção e verificando sucesso
            if(mysqli_query($conexao, $sql)){
                echo "Login efetuado com sucesso";
            }else{
                echo "Erro: ".mysqli_error($conexao);
            }
            mysqli_close($conexao);
        }
        
    }