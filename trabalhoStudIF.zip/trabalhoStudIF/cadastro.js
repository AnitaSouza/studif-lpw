function cadastrarDados(){
  var resposta = document.getElementById("resposta");
  resposta = "Seus dados foram cadastrados";
  alert(resposta);
}

function validarFormCadastro(){
  var nome = document.forms["formularioCadastro"]["nome_cad"];
  var mensagem1 = document.getElementById("mensagem1");

  if(nome.value==""){
    mensagem1.innerHTML = "Preencha o campo nome";
    mensagem1.style.color="red";
    return false;
  }else{
    nome.classList.remove("erro");
    nome.classList.add("sucesso"); 
  }
  return true;
}
    