<?php
    require_once("Login.class.php");

    $email_login = $_POST["email_login"];
    $senha_login = $_POST["senha_login"];

    $objetoLogin = new Login($email_login, $senha_login);
    $objetoLogin->exibirDados();
    $objetoLogin->inserirLogin();