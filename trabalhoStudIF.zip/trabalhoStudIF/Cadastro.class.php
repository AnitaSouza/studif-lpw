<?php
    class Cadastro{
        private $nome_cad;
        private $email_cad;
        private $nascimento_cad; 
        private $senha_cad;
        private $confsenha_cad;

        public function exibirDados(){
            echo "<br />";
            echo "O nome é ". $this->nome_cad;
            echo "<br />";
            echo "O e-mail  é ". $this->email_cad;
            echo "<br />";
            echo "A data de nascimento é ". $this->nascimento_cad;
            echo "<br />";
            echo "A senha é ". $this->senha_cad;
            echo "<br />";
            echo "Confirme sua senha ". $this->confsenha_cad;
        }

        public function __construct($nome_cad,$email_cad,$nascimento_cad,$senha_cad,$confsenha_cad){
            $this->nome_cad = $nome_cad;
            $this->email_cad = $email_cad;
            $this->nascimento_cad = $nascimento_cad;
            $this->senha_cad = $senha_cad;
            $this->confsenha_cad = $confsenha_cad;
            echo "<br />cadastro criado...";
        }

        public function setNome($nome_cad){
            $this->nome_cad = $nome_cad;
        }
        
        public function getNome(){
            return $this->nome_cad;
        }

        public function setEmail($email_cad){
            $this->email_cad = $email_cad;
        }
        
        public function getEmail(){
            return $this->email_cad;
        }

        public function setNascimento($nascimento_cad){
            $this->nascimento_cad = $nascimento_cad;
        }
        
        public function getNascimento(){
            return $this->nascimento_cad;
        }

        public function setSenha($senha_cad){
            $this->senha_cad = $senha_cad;
        }
        
        public function getSenha(){
            return $this->senha_cad;
        }

        public function setConfirmar($confsenha_cad){
            $this->confsenha_cad = $confsenha_cad;
        }
        
        public function getConfirmar(){
            return $this->confsenha_cad;
        }

        public function inserirCadastro()
        {
            //Conectar com o BD
            $conexao = mysqli_connect("localhost","root","", "studif");
            
            //Verificando a conexão
            if(!$conexao){
                die("Falha na conexão com o BD");
            }
            echo "<br />";
            echo "Conectado com o banco";

            //Criando a string de inserção (código SQL)
            $sql = "INSERT INTO cadastro VALUES ('$this->nome_cad', '$this->email_cad', '$this->nascimento_cad','$this->senha_cad', '$this->confsenha_cad')";
           
            //Executando a inserção e verificando sucesso
            if(mysqli_query($conexao, $sql)){
                echo "Cadastro realizado com sucesso";
            }else{
                echo "Erro: ".mysqli_error($conexao);
            }
            mysqli_close($conexao);
        }
        
    }