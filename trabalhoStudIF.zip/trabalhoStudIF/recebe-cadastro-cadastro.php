<?php
    require_once("Cadastro.class.php");

    $nome_cad = $_POST["nome_cad"];
    $email_cad = $_POST["email_cad"];
    $nascimento_cad = $_POST["nascimento_cad"];
    $senha_cad = $_POST["senha_cad"];
    $confsenha_cad = $_POST["confsenha_cad"];

    $objetoCadastro = new Cadastro($nome_cad, $email_cad, $nascimento_cad,$senha_cad,$confsenha_cad);
    $objetoCadastro->exibirDados();
    $objetoCadastro->inserirCadastro();