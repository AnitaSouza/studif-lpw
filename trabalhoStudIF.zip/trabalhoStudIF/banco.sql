CREATE DATABASE studif;
USE studif;
CREATE TABLE cadastro(
    nome_cad VARCHAR (100),
    email_cad VARCHAR(100),
    nascimento_cad INT(9),
    senha_cad VARCHAR(10),
    confsenha_cad VARCHAR(10)
);
CREATE TABLE login(
    email_login VARCHAR(100),
    senha_login VARCHAR(10)
);
