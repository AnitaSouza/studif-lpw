function validar(){
  var email = document.forms["formulario"]["email_login"];
  var senha = document.forms["formulario"]["senha_login"];
  var mensagem1 = document.getElementById("mensagem1");

  if(nome.value==""){
    mensagem1.innerHTML = "Preencha o campo nome";
    mensagem1.style.color="red";
    return false;
  }else{
    nome.classList.remove("erro");
    nome.classList.add("sucesso"); 
  }
  return true;
}

